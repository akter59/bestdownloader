document.addEventListener('DOMContentLoaded', () => {
  // Base URL for API (Leave empty if backend is hosted together, or set window.API_BASE)
  const API_BASE = (window.API_BASE || '').replace(/\/+$/, '');

  const downloadForm = document.getElementById('downloadForm');
  const videoUrlInput = document.getElementById('videoUrl');
  const pasteBtn = document.getElementById('pasteBtn');
  const submitBtn = document.getElementById('submitBtn');
  const btnText = document.getElementById('btnText');
  const btnIcon = document.getElementById('btnIcon');

  const loadingBox = document.getElementById('loadingBox');
  const errorBox = document.getElementById('errorBox');
  const errorMessage = document.getElementById('errorMessage');
  const resultCard = document.getElementById('resultCard');

  const videoThumb = document.getElementById('videoThumb');
  const videoDuration = document.getElementById('videoDuration');
  const platformBadge = document.getElementById('platformBadge');
  const videoTitle = document.getElementById('videoTitle');
  const videoUploader = document.getElementById('videoUploader');
  const formatList = document.getElementById('formatList');

  // Paste from clipboard handler
  pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        videoUrlInput.value = text.trim();
        videoUrlInput.focus();
      }
    } catch (err) {
      alert('ক্লিপবোর্ড থেকে পেস্ট করার অনুমতি মেলেনি। দয়া করে ম্যানুয়ালি পেস্ট (Ctrl+V) করুন।');
    }
  });

  // Handle Form Submit
  downloadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const url = videoUrlInput.value.trim();

    if (!url) {
      showError('অনুগ্রহ করে একটি বৈধ ফেসবুক বা ইউটিউব ভিডিও লিঙ্ক দিন।');
      return;
    }

    // Reset UI
    hideError();
    resultCard.classList.add('hidden');
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/info`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'ভিডিও লোড করতে ব্যর্থ হয়েছে।');
      }

      displayResult(data);

    } catch (err) {
      showError(err.message || 'নেটওয়ার্ক বা সার্ভারে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  });

  function setLoading(isLoading) {
    if (isLoading) {
      loadingBox.classList.remove('hidden');
      submitBtn.disabled = true;
      btnText.textContent = 'অপেক্ষা করুন...';
      btnIcon.className = 'fa-solid fa-spinner fa-spin';
    } else {
      loadingBox.classList.add('hidden');
      submitBtn.disabled = false;
      btnText.textContent = 'খুঁজুন';
      btnIcon.className = 'fa-solid fa-arrow-right';
    }
  }

  function showError(msg) {
    errorMessage.textContent = msg;
    errorBox.classList.remove('hidden');
    errorBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function hideError() {
    errorBox.classList.add('hidden');
    errorMessage.textContent = '';
  }

  function displayResult(data) {
    // Thumbnail & Duration
    videoThumb.src = data.thumbnail || 'https://via.placeholder.com/640x360?text=No+Thumbnail';
    videoDuration.textContent = data.duration || '00:00';
    videoTitle.textContent = data.title;
    videoUploader.querySelector('span').textContent = data.uploader || 'Unknown';

    // Platform Badge styling
    const plat = (data.platform || '').toLowerCase();
    if (plat.includes('youtube')) {
      platformBadge.className = 'absolute top-2 left-2 px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md shadow bg-red-600/80 text-white border border-red-400/30';
      platformBadge.innerHTML = '<i class="fa-brands fa-youtube mr-1"></i> YouTube';
    } else if (plat.includes('facebook')) {
      platformBadge.className = 'absolute top-2 left-2 px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md shadow bg-blue-600/80 text-white border border-blue-400/30';
      platformBadge.innerHTML = '<i class="fa-brands fa-facebook mr-1"></i> Facebook';
    } else {
      platformBadge.className = 'absolute top-2 left-2 px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md shadow bg-emerald-600/80 text-white border border-emerald-400/30';
      platformBadge.innerHTML = `<i class="fa-solid fa-video mr-1"></i> ${data.platform || 'Video'}`;
    }

    // Populate Formats List
    formatList.innerHTML = '';

    if (!data.options || data.options.length === 0) {
      formatList.innerHTML = '<p class="text-xs text-slate-400">কোনো ডাউনলোড ফরম্যাট পাওয়া যায়নি।</p>';
    } else {
      data.options.forEach(opt => {
        const item = document.createElement('div');
        item.className = 'flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition';

        const isAudio = opt.type === 'audio';
        const iconClass = isAudio ? 'fa-solid fa-music text-amber-400' : 'fa-solid fa-film text-emerald-400';
        const badgeColor = isAudio ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

        item.innerHTML = `
          <div class="flex items-center gap-2.5">
            <span class="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-sm">
              <i class="${iconClass}"></i>
            </span>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-sm font-semibold text-white">${opt.quality}</span>
                <span class="px-1.5 py-0.5 rounded text-[10px] font-mono border ${badgeColor}">${opt.format}</span>
              </div>
            </div>
          </div>
          <button 
            type="button" 
            class="dl-trigger-btn px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 active:scale-95 shadow-md shadow-emerald-500/20"
            data-url="${encodeURIComponent(data.url)}"
            data-type="${opt.type}"
            data-quality="${opt.target || '720'}">
            <i class="fa-solid fa-download"></i> 
            <span>ডাউনলোড</span>
          </button>
        `;

        formatList.appendChild(item);
      });

      // Bind download buttons
      document.querySelectorAll('.dl-trigger-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const button = e.currentTarget;
          const targetUrl = button.getAttribute('data-url');
          const type = button.getAttribute('data-type');
          const quality = button.getAttribute('data-quality');

          const originalContent = button.innerHTML;
          button.disabled = true;
          button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> <span>প্রস্তুত হচ্ছে...</span>';

          const downloadLink = `${API_BASE}/api/download?url=${targetUrl}&type=${type}&quality=${quality}`;
          
          // Trigger direct file download
          window.location.href = downloadLink;

          // Re-enable after 6 seconds
          setTimeout(() => {
            button.disabled = false;
            button.innerHTML = originalContent;
          }, 6000);
        });
      });
    }

    resultCard.classList.remove('hidden');
    resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
});
